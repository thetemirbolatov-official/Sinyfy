# SINYFY v1.0

**Static Site Visual Cloner** - Инструмент для клонирования веб-сайтов в статическую версию без использования Selenium.

[![PyPI version](https://img.shields.io/pypi/v/sinyfy.svg)](https://pypi.org/project/sinyfy/)
[![Python Versions](https://img.shields.io/pypi/pyversions/sinyfy.svg)](https://pypi.org/project/sinyfy/)
[![License](https://img.shields.io/github/license/thetemirbolatov/sinyfy.svg)](https://github.com/thetemirbolatov/sinyfy/blob/main/LICENSE)
[![Downloads](https://pepy.tech/badge/sinyfy)](https://pepy.tech/project/sinyfy)

## 📋 Описание

SINYFY - это легковесный инструмент для создания статической копии веб-сайта. Он скачивает HTML, извлекает все стили (включая инлайн), сохраняет изображения локально и создает полностью автономную версию сайта.

### 🌟 Особенности

- ✅ **Простота использования** - одна команда для клонирования сайта
- ✅ **Без Selenium** - работает только с HTTP запросами
- ✅ **Автономная версия** - все ресурсы сохраняются локально
- ✅ **CSS обработка** - извлекает внешние и инлайн стили
- ✅ **Изображения** - скачивает и оптимизирует
- ✅ **Заглушки** - создает плейсхолдеры для недоступных изображений
- ✅ **Безопасность** - удаляет JavaScript и обработчики событий
- ✅ **Кроссплатформенность** - работает на Windows, macOS, Linux

## 🚀 Установка

### Через pip (рекомендуется)

```bash
pip install Sinyfy
```

Из исходников
```bash
git clone https://github.com/thetemirbolatov-official/Sinyfy.git
cd Sinyfy
```
```bash
pip install -e .
```

📖 Использование
Базовое использование
```bash
# Простое клонирование сайта
Sinyfy https://example.com
```

# Загрузка - Sinyfy загружает HTML страницы

Парсинг - анализирует структуру документа

# CSS обработка:

Извлекает все <style> теги

Скачивает внешние CSS файлы

Преобразует инлайн стили в отдельные классы

# Изображения:

Скачивает все изображения

Конвертирует data URI в файлы

Создает заглушки для недоступных изображений

# Очистка:

Удаляет JavaScript

Убирает обработчики событий

Нормализует ссылки

# Сохранение:

index.html - очищенная страница

style.css - все стили в одном файле

images/ - все изображения

manifest.json - информация о ресурсах

# Пример результата
```bash
text
output/
├── index.html
├── style.css
├── manifest.json
└── images/
    ├── image_0001.png
    ├── image_0002.jpg
    ├── bg_0001.png
    └── placeholder_0001.png
```
# 🛠 Требования
Python 3.7 или выше

# Зависимости автоматически устанавливаются:

requests - для HTTP запросов

beautifulsoup4 - для парсинга HTML

Pillow - для обработки изображений

# 🤝 Вклад в развитие
Форкните репозиторий

Создайте ветку для фичи (git checkout -b feature/amazing-feature)

Закоммитьте изменения (git commit -m 'Add amazing feature')

Запушьте ветку (git push origin feature/amazing-feature)

Откройте Pull Request

# 📄 Лицензия
MIT License. Смотрите файл LICENSE для деталей.

# 👨‍💻 Автор
thetemirbolatov

GitHub: @thetemirbolatov-official

PyPI: thetemirbolatov

# Sinyfy - сделано для простого клонирования сайтов
